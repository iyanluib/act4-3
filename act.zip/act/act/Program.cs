﻿using System;
using MySql.Data.MySqlClient;

using act12 = act;



class Prgram
{
    public static void Main()
    {
        act12.Home.MainHome();
    }
}